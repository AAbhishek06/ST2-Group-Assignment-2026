import unittest
import sys
import os

sys.path.append(
    os.path.abspath(
        os.path.join(os.path.dirname(__file__), "..")
    )
)

from Phase_1.stack_queue import StackQueueVisualiser


class TestStackQueue(unittest.TestCase):
    def test_stack_add(self):
        vis = StackQueueVisualiser()

        vis.stack.append(10)
        vis.stack.append(20)

        self.assertEqual(vis.stack, [10, 20])

    def test_stack_remove(self):
        vis = StackQueueVisualiser()

        vis.stack.append(10)
        vis.stack.append(20)

        value = vis.stack.pop()

        self.assertEqual(value, 20)
        self.assertEqual(vis.stack, [10])

    def test_stack_empty(self):
        vis = StackQueueVisualiser()

        value = vis.stack.pop() if vis.stack else None

        self.assertIsNone(value)

    def test_queue_add(self):
        vis = StackQueueVisualiser()

        vis.queue.append(10)
        vis.queue.append(20)

        self.assertEqual(list(vis.queue), [10, 20])

    def test_queue_remove(self):
        vis = StackQueueVisualiser()

        vis.queue.append(10)
        vis.queue.append(20)

        value = vis.queue.popleft()

        self.assertEqual(value, 10)
        self.assertEqual(list(vis.queue), [20])

    def test_queue_empty(self):
        vis = StackQueueVisualiser()

        value = vis.queue.popleft() if len(vis.queue) > 0 else None

        self.assertIsNone(value)

if __name__ == "__main__":
    unittest.main()