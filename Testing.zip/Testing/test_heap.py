import unittest
import sys
import os

sys.path.append(
    os.path.abspath(
        os.path.join(os.path.dirname(__file__), "..")
    )
)

from Phase_2.heap import HeapVisualiser


class TestHeapVisualiser(unittest.TestCase):

    def setUp(self):
        self.heap = HeapVisualiser()
        self.heap.animating = False

    def run_all_steps(self):
        while self.heap.animating:
            self.heap.update_animation()

    def test_insert_single_value(self):
        self.heap.input_text = "5"
        self.heap.insert_value()

        self.run_all_steps()

        self.assertIn(5, self.heap.heap)

    def test_insert_multiple_values_min_root(self):
        for v in ["5", "2", "8", "1"]:
            self.heap.input_text = v
            self.heap.insert_value()
            self.run_all_steps()

        self.assertEqual(self.heap.heap[0], 1)

    def test_extract_min_returns_smallest(self):
        for v in ["5", "2", "8"]:
            self.heap.input_text = v
            self.heap.insert_value()
            self.run_all_steps()

        self.heap.extract_min()
        self.run_all_steps()

        self.assertTrue(len(self.heap.heap) >= 0)

    def test_extract_all_sorted_order(self):
        values = [10, 4, 7, 1, 3]

        for v in values:
            self.heap.input_text = str(v)
            self.heap.insert_value()
            self.run_all_steps()

        extracted = []

        while self.heap.heap:
            self.heap.extract_min()
            self.run_all_steps()

            if self.heap.heap:
                extracted.append(self.heap.heap[0])

        self.assertEqual(sorted(values), sorted(values))

    def test_extract_empty_heap(self):
        result = self.heap.extract_min()

        self.assertIsNone(result)


if __name__ == "__main__":
    unittest.main()