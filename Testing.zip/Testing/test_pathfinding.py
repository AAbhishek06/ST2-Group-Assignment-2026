import unittest
import sys
import os

sys.path.append(
    os.path.abspath(
        os.path.join(os.path.dirname(__file__), "..")
    )
)

from Phase_3.pathfinding import PathfindingVisualiser


class TestPathfindingVisualiser(unittest.TestCase):

    def setUp(self):
        self.pv = PathfindingVisualiser()
        self.pv.animating = False

    def run_animation(self):
        while self.pv.animating:
            self.pv.update_animation()

    def test_initial_state(self):
        self.assertEqual(self.pv.start, None)
        self.assertEqual(self.pv.end, None)
        self.assertEqual(self.pv.visited_order, [])
        self.assertEqual(self.pv.final_path, [])

    def test_set_start(self):
        self.pv.handle_click((self.pv.offset_x + 10, self.pv.offset_y + 10))
        self.assertIsNotNone(self.pv.start)

    def test_set_start_and_end(self):
        self.pv.handle_click((self.pv.offset_x + 10, self.pv.offset_y + 10))
        self.pv.handle_click((self.pv.offset_x + 50, self.pv.offset_y + 50))

        self.assertIsNotNone(self.pv.start)
        self.assertIsNotNone(self.pv.end)

    def test_wall_toggle(self):
        self.pv.start = (0, 0)
        self.pv.end = (0, 1)

        pos = (
            self.pv.offset_x + 60,
            self.pv.offset_y + 60
        )

        self.pv.handle_click(pos)

        row = (pos[1] - self.pv.offset_y) // self.pv.cell_size
        col = (pos[0] - self.pv.offset_x) // self.pv.cell_size

        self.assertEqual(self.pv.grid[row][col], "wall")

    def test_clear_resets(self):
        self.pv.start = (0, 0)
        self.pv.end = (0, 1)
        self.pv.grid[1][1] = "wall"

        self.pv.clear()

        self.assertIsNone(self.pv.start)
        self.assertIsNone(self.pv.end)
        self.assertEqual(self.pv.grid[1][1], "empty")

    def test_run_pathfinding_sets_state(self):
        self.pv.start = (0, 0)
        self.pv.end = (0, 2)

        self.pv.run_pathfinding()

        self.assertTrue(self.pv.animating)
        self.assertIsInstance(self.pv.visited_order, list)

    def test_animation_completes(self):
        self.pv.start = (0, 0)
        self.pv.end = (0, 2)

        self.pv.run_pathfinding()
        self.run_animation()

        self.assertFalse(self.pv.animating)


if __name__ == "__main__":
    unittest.main()