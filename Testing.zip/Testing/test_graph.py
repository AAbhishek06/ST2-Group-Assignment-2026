import unittest
import sys
import os

sys.path.append(
    os.path.abspath(
        os.path.join(os.path.dirname(__file__), "..")
    )
)

from Phase_2.graph import GraphVisualizer

class TestGraphVisualizer(unittest.TestCase):

    def test_initial_state(self):
        vis = GraphVisualizer()

        self.assertEqual(vis.visited, set())
        self.assertEqual(vis.visit_order, [])
        self.assertIsNone(vis.start_node)
        self.assertFalse(vis.auto_running)

    def test_set_start_node(self):
        vis = GraphVisualizer()

        vis.set_start("A")

        self.assertEqual(vis.start_node, "A")
        self.assertEqual(vis.current, "A")
        self.assertIn("Start node set", vis.status_message)

    def test_set_invalid_start_node(self):
        vis = GraphVisualizer()

        vis.set_start("Z")

        self.assertIsNone(vis.start_node)

    def test_reset(self):
        vis = GraphVisualizer()

        vis.set_start("A")
        vis.visited.add("A")
        vis.visit_order.append("A")
        vis.auto_running = True

        vis.reset()

        self.assertEqual(vis.visited, set())
        self.assertEqual(vis.visit_order, [])
        self.assertFalse(vis.auto_running)
        self.assertIsNone(vis.mode)

    def test_start_bfs_requires_start(self):
        vis = GraphVisualizer()

        vis.start_bfs()

        self.assertEqual(vis.status_message, "Select start node first")

    def test_start_dfs_requires_start(self):
        vis = GraphVisualizer()

        vis.start_dfs()

        self.assertEqual(vis.status_message, "Select start node first")

    def test_bfs_step_basic(self):
        vis = GraphVisualizer()

        vis.set_start("A")
        vis.start_bfs()

        vis.step()

        self.assertTrue(len(vis.visit_order) >= 1)
        self.assertIn(vis.visit_order[0], ["A", "B", "C"])

    def test_dfs_step_basic(self):
        vis = GraphVisualizer()

        vis.set_start("A")
        vis.start_dfs()

        vis.step()

        self.assertTrue(len(vis.visit_order) >= 1)

if __name__ == "__main__":
    unittest.main()