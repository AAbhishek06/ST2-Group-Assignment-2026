import unittest
import sys
import os

sys.path.append(
    os.path.abspath(
        os.path.join(os.path.dirname(__file__), "..")
    )
)

from Phase_2.sorting import SortingVisualiser

class TestSorting(unittest.TestCase):

    def test_generate_values(self):
        vis = SortingVisualiser()

        vis.input_text = "10"
        vis.randomise()

        self.assertEqual(len(vis.numbers), 10)
        self.assertEqual(len(vis.original_numbers), 10)

    def test_generate_invalid_low(self):
        vis = SortingVisualiser()

        vis.input_text = "0"
        vis.randomise()

        self.assertEqual(vis.status_message, "Range 1 to 50 only")

    def test_generate_invalid_high(self):
        vis = SortingVisualiser()

        vis.input_text = "51"
        vis.randomise()

        self.assertEqual(vis.status_message, "Range 1 to 50 only")

    def test_reset(self):
        vis = SortingVisualiser()

        vis.numbers = [5, 2, 1]
        vis.original_numbers = [5, 2, 1]

        vis.reset()

        self.assertEqual(vis.numbers, vis.original_numbers)

    def test_choose_algorithm(self):
        vis = SortingVisualiser()

        vis.choose_algorithm("Merge Sort")

        self.assertEqual(vis.algorithm, "Merge Sort")

    def test_clear_state(self):
        vis = SortingVisualiser()

        vis.steps = [1, 2, 3]
        vis.step_index = 5
        vis.sorting = True

        vis.clear_state()

        self.assertEqual(vis.steps, [])
        self.assertEqual(vis.step_index, 0)
        self.assertFalse(vis.sorting)


if __name__ == "__main__":
    unittest.main()