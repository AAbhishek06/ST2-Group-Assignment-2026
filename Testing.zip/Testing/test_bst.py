import unittest
import sys
import os

sys.path.append(
    os.path.abspath(
        os.path.join(os.path.dirname(__file__), "..")
    )
)

from Phase_1.bst import BinarySearchTree


class TestBST(unittest.TestCase):

    def test_insert(self):
        tree = BinarySearchTree()

        tree.insert(10)
        tree.insert(5)
        tree.insert(15)

        self.assertEqual(tree.inorder(), [5, 10, 15])

    def test_duplicate(self):
        tree = BinarySearchTree()

        self.assertTrue(tree.insert(10))
        self.assertFalse(tree.insert(10))

    def test_clear(self):
        tree = BinarySearchTree()

        tree.insert(10)
        tree.clear()

        self.assertEqual(tree.inorder(), [])


if __name__ == "__main__":
    unittest.main()