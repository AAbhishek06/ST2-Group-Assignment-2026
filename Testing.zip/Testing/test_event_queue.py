import unittest
import sys
import os

sys.path.append(
    os.path.abspath(
        os.path.join(os.path.dirname(__file__), "..")
    )
)

from Phase_3.event_queue import EventQueueVisualiser


class TestEventQueueVisualiser(unittest.TestCase):

    def setUp(self):
        self.v = EventQueueVisualiser()
        self.v.animating = False

    def run_animation(self):
        while self.v.animating:
            self.v.update_animation()

    def test_initial_state(self):
        self.assertEqual(self.v.heap, [])
        self.assertEqual(self.v.processed_events, [])

    def test_add_event(self):
        self.v.input_name = "A"
        self.v.input_priority = "1"

        self.v.add_event()

        self.assertEqual(len(self.v.heap), 1)

    def test_add_invalid_event_empty_name(self):
        self.v.input_name = ""
        self.v.input_priority = "1"

        self.v.add_event()

        self.assertEqual(len(self.v.heap), 0)

    def test_add_invalid_event_priority(self):
        self.v.input_name = "A"
        self.v.input_priority = "x"

        self.v.add_event()

        self.assertEqual(len(self.v.heap), 0)

    def test_start_processing_empty(self):
        self.v.start_processing()

        self.assertFalse(self.v.animating)

    def test_start_processing_with_events(self):
        self.v.input_name = "A"
        self.v.input_priority = "2"
        self.v.add_event()

        self.v.input_name = "B"
        self.v.input_priority = "1"
        self.v.add_event()

        self.v.start_processing()

        self.assertTrue(self.v.animating)

    def test_manual_step_processes_event(self):
        self.v.input_name = "A"
        self.v.input_priority = "1"
        self.v.add_event()

        self.v.manual_step()

        self.assertEqual(len(self.v.processed_events), 1)

    def test_manual_step_empty_queue(self):
        self.v.manual_step()

        self.assertEqual(len(self.v.processed_events), 0)

    def test_reset_clears_state(self):
        self.v.input_name = "A"
        self.v.input_priority = "1"
        self.v.add_event()

        self.v.reset()

        self.assertEqual(self.v.heap, [])
        self.assertEqual(self.v.processed_events, [])

    def test_processing_completes(self):
        self.v.input_name = "A"
        self.v.input_priority = "2"
        self.v.add_event()

        self.v.input_name = "B"
        self.v.input_priority = "1"
        self.v.add_event()

        self.v.start_processing()
        self.run_animation()

        self.assertFalse(self.v.animating)


if __name__ == "__main__":
    unittest.main()