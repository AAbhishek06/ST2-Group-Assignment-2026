import unittest
import sys
import os

sys.path.append(
    os.path.abspath(
        os.path.join(os.path.dirname(__file__), "..")
    )
)

from Phase_3.dynamic import DynamicProgrammingVisualiser


class TestDynamicProgrammingVisualiser(unittest.TestCase):

    def test_initial_state(self):
        vis = DynamicProgrammingVisualiser()

        self.assertIsNone(vis.start)
        self.assertIsNone(vis.end)
        self.assertEqual(len(vis.grid), 25)
        self.assertEqual(len(vis.grid[0]), 25)

    def test_set_start(self):
        vis = DynamicProgrammingVisualiser()

        x = vis.offset_x + 10
        y = vis.offset_y + 10

        vis.handle_click((x, y))

        self.assertIsNotNone(vis.start)
        self.assertEqual(vis.status_message, "Start set")

    def test_set_start_and_end(self):
        vis = DynamicProgrammingVisualiser()

        vis.handle_click((vis.offset_x + 10, vis.offset_y + 10))
        vis.handle_click((vis.offset_x + 50, vis.offset_y + 10))

        self.assertIsNotNone(vis.start)
        self.assertIsNotNone(vis.end)

    def test_add_wall_toggle_fixed(self):
        vis = DynamicProgrammingVisualiser()

        start_x = vis.offset_x + 10
        start_y = vis.offset_y + 10

        end_x = vis.offset_x + 50
        end_y = vis.offset_y + 10

        wall_x = vis.offset_x + 90
        wall_y = vis.offset_y + 10

        vis.handle_click((start_x, start_y))
        vis.handle_click((end_x, end_y))

        vis.handle_click((wall_x, wall_y))

        row = (wall_y - vis.offset_y) // vis.cell_size
        col = (wall_x - vis.offset_x) // vis.cell_size

        self.assertEqual(vis.grid[row][col], "wall")

    def test_clear(self):
        vis = DynamicProgrammingVisualiser()

        vis.handle_click((vis.offset_x + 10, vis.offset_y + 10))
        vis.handle_click((vis.offset_x + 50, vis.offset_y + 10))

        vis.clear()

        self.assertIsNone(vis.start)
        self.assertIsNone(vis.end)
        self.assertEqual(vis.status_message, "Grid cleared")

    def test_run_without_start_end(self):
        vis = DynamicProgrammingVisualiser()

        vis.run_dp()

        self.assertEqual(vis.status_message, "Set start and end first")
        self.assertFalse(vis.animating)

    def test_run_basic(self):
        vis = DynamicProgrammingVisualiser()

        vis.start = (0, 0)
        vis.end = (0, 1)

        vis.run_dp()

        self.assertTrue(vis.animating)
        self.assertIn("DP complete", vis.status_message)

    def test_reconstruct_path(self):
        vis = DynamicProgrammingVisualiser()

        vis.start = (0, 0)
        vis.end = (0, 2)

        vis.dp = [[0 for _ in range(25)] for _ in range(25)]
        vis.dp[0][0] = 1
        vis.dp[0][1] = 1
        vis.dp[0][2] = 1

        path = vis.reconstruct_path(1, 1)

        self.assertTrue(len(path) >= 1)


if __name__ == "__main__":
    unittest.main()