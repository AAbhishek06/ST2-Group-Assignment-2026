import unittest
import sys
import os

sys.path.append(
    os.path.abspath(
        os.path.join(os.path.dirname(__file__), "..")
    )
)

from Phase_1.linked_list import SingleLinkedList


class TestLinkedList(unittest.TestCase):

    def test_insert_at_index(self):
        ll = SingleLinkedList()

        ll.insert_at_index(10, 0)
        ll.insert_at_index(20, 1)

        self.assertEqual(ll.to_list(), [10, 20])

    def test_insert_middle(self):
        ll = SingleLinkedList()

        ll.insert_at_index(10, 0)
        ll.insert_at_index(30, 1)
        ll.insert_at_index(20, 1)

        self.assertEqual(ll.to_list(), [10, 20, 30])

    def test_delete_value(self):
        ll = SingleLinkedList()

        ll.insert_at_index(10, 0)
        ll.insert_at_index(20, 1)

        ll.delete_value(10)

        self.assertEqual(ll.to_list(), [20])

    def test_search(self):
        ll = SingleLinkedList()

        ll.insert_at_index(5, 0)
        ll.insert_at_index(10, 1)
        ll.insert_at_index(15, 2)

        self.assertEqual(ll.search(10), 1)

    def test_reverse(self):
        ll = SingleLinkedList()

        ll.insert_at_index(1, 0)
        ll.insert_at_index(2, 1)
        ll.insert_at_index(3, 2)

        ll.reverse()

        self.assertEqual(ll.to_list(), [3, 2, 1])

    def test_clear(self):
        ll = SingleLinkedList()

        ll.insert_at_index(1, 0)
        ll.insert_at_index(2, 1)

        ll.clear()

        self.assertEqual(ll.to_list(), [])


if __name__ == "__main__":
    unittest.main()